
function getDomInfo() {
  var dom_ul_li_arr = document.querySelectorAll('div#arbsScroll > div.scroller > ul > li');  
  let infoDataArr = [];
  for(var ii = 0 ; ii < dom_ul_li_arr.length; ii++) {
    let rowObj = {
      gameType: '',
      gamePercent: '',
      rows : [] //{team_1 : "",team_2 : "",matchCategory: "",attr_str: "",attr_val: "",} 
    };
    var t_dom = dom_ul_li_arr[ii];
    rowObj.gameType = t_dom.querySelector("span.sport").textContent.trim();
    rowObj.gamePercent = t_dom.querySelector("div.betPercent div.inside span").textContent.trim();
    for(let i = 0; i < 2; i++) {
      var tObj = {};
      var tArr;
      if(t_dom.querySelectorAll("div.betLeague > div > a")[i].textContent.includes("↔")) {
        tArr = t_dom.querySelectorAll("div.betLeague > div > a")[i].textContent.split(" ↔ ");
      } else {
        tArr = t_dom.querySelectorAll("div.betLeague > div > a")[i].textContent.split(" - ");
      }
      
      tObj.team_1 = tArr[0].trim();
      tObj.team_2 = tArr[1].trim();
      tObj.matchCategory = t_dom.querySelectorAll("div.betLeague > small.text-muted")[i].textContent.trim();
      tObj.attr_str = t_dom.querySelectorAll("div.compareLinkContainer > a")[i].textContent.trim();
      tObj.attr_val = t_dom.querySelectorAll("div.betMarketDeep > div > div.outcomeKoef > a")[i].textContent.trim();
      rowObj.rows.push(tObj);
    }
    infoDataArr.push(rowObj);
  }

  return infoDataArr;
}

//================================================================================================
//

let isGoing = false;
var socket;
setTimeout(function() {
  socket = io.connect('http://localhost:3002');
}, 1000);
var MutationObserver    = window.MutationObserver || window.WebKitMutationObserver;
var obsConfig           = { childList: true, characterData: true, attributes: true, subtree: true };
var myObserver          = new MutationObserver (mutationHandler);


function mutationHandler (mutationRecords) {
  if(isGoing) {
    console.log("isGoing===>", isGoing);
    console.info ("==>", getDomInfo());
    socket.emit('scrapingData', getDomInfo());
  }
}

function onRequest(request, sender, sendResponse) {
  console.log('--------content-page------------------');
  if(request.action == 'bid_jobs') {
    chrome.storage.local.get("bid_status", function(obj){
      if(obj.bid_status === 'go') {
        isGoing = true;
      } else {
        isGoing = false;
      }
    });
  }
  myObserver.observe ($('div#arbsScroll > div.scroller')[0], obsConfig);
}

chrome.runtime.onMessage.addListener(onRequest);