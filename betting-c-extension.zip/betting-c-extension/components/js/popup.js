var LocalStorage = new LocalStorage();
LocalStorage.init();

function getCurrentTab(callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    callback(tabs[0]);
  });
}

function isTabLinkedin(tab) {
  return 1;
  //return tab.url.indexOf('facebook.com') + 1;
}


function sendMessageForAddContacts(tab, status, msgTxt, actionNums) { 

  chrome.tabs.sendMessage(
    tab.id, {
      action: 'add_contacts',
      status: status,
      msgTxt: msgTxt,
      actionNums: actionNums
    });
}

function addContacts(status, msgTxt, actionNums) {
  getCurrentTab(function(currentTab) {
    if (isTabLinkedin(currentTab)) {
      sendMessageForAddContacts(currentTab, status, msgTxt, actionNums);
    }
  });
}
  
function openTab(url) {
  chrome.tabs.create({ 'url': url });
}

function updateNumberOfTotalAdded(totalAdded) {
  $('#total_added_number').text(totalAdded);
}

function generateLinks() {
  $('[data-link-url]').click(function() {
    openTab(this.getAttribute('data-link-url'));
  });
}

function translatePage() {
  var translation, attr;

  $('[data-translation]').each(function() {
    translation = this.getAttribute('data-translation');
    attr = this.getAttribute('data-translation-attr');

    if (attr !== null) {
      this.setAttribute(attr, chrome.i18n.getMessage(translation));
    } else {
      this.textContent = chrome.i18n.getMessage(translation);
    }
  });
}


function showNumberInvitedNow(number) {
  console.log("number=====>", number);
  $("#number_invited_now").text(number + ' invitations was sent');
}


function buttonStopLoading() {
  var button = $('.button-loaded');

  $(button).text($(button).attr('data-add-contacts'));
  $(button).removeClass('button-loaded');
}

function listIsEmpty() {
  return parseInt($('#number_invited_now').text()) == 0;
}

function generateListOfInvitedContacts(data) {
  var isListEmpty = listIsEmpty();

  showNumberInvitedNow(data.addedContacts.length);
  console.log("data.totalAdded=========>", data.addedContacts);

  var contact, newBlock,
    resultsBlock = '#results',
    listGroupBlock = '.list-group',
    firstBlock = resultsBlock + ' .list-group-item:first';

  if (!isListEmpty) {
    firstBlock = resultsBlock + ' .list-group-item:last';
  }

  for (var key in data.addedContacts) {
    contact = data.addedContacts[key];

    if (contact !== null) {
      newBlock = $(firstBlock).clone();

      $(newBlock).find('.row-picture img')
        .attr('src', contact.img)
        .attr('data-link-url', contact.link);
      $(newBlock).find('.row-content .list-group-item-heading')
        .text(contact.initials)
        .attr('data-link-url', contact.link);
      $(newBlock).find('.row-content .list-group-item-text')
        .text(contact.title);

      $(newBlock).appendTo($(resultsBlock + ' ' + listGroupBlock));
    }
  }

  if (isListEmpty) {
    $(firstBlock).remove();
    $(resultsBlock).fadeIn();
  }
}

function showNumOfActiveFilters() {
  var numOfActiveFilters = 0;

  $.each($('#filters .togglebutton [type="checkbox"]'), function(key, el) {
    if (el.checked) {
      numOfActiveFilters++;
      $(el).parents('.form-group').addClass('active-filter');
    } else {
      $(el).parents('.form-group').removeClass('active-filter');
    }
  });

  $('#number_activated_filters').text(numOfActiveFilters);
}

function filterListeners() {
  $('#profession').keyup(function() {
    if (this.value == '') {
      $('#professionFilterStatus').prop('checked', false);
    } else {
      $('#professionFilterStatus').prop('checked', true);
    }

    showNumOfActiveFilters();
  });

  $('#filters .togglebutton [type="checkbox"]').change(showNumOfActiveFilters);
}

function getFilters() {
  var filters = {},
    input;

  $.each($('#filters .togglebutton [type="checkbox"]'), function(key, el) {
    if (el.checked) {
      input = $(el).parents('.form-group').find('.filter');

      if ($(input).val() !== '') {
        filters[$(input).attr('id')] = $(input).val();
      }
    }
  });

  return $.isEmptyObject(filters) ? null : filters;
}

function showErrorNothingToAdding() {
  $('#nothing_to_added').fadeIn(1000);

  setTimeout(function() {
    $('#nothing_to_added').fadeOut(2000);
  }, 5000);
}


function getBidStatus() {
  chrome.storage.local.get("bid_status", function(obj){
    console.log("obj.bid_status", obj.bid_status);
    if(obj.bid_status == 'go') {
      $("#btn_bid_stop").show();
      $('#btn_bid_go').hide();
      $("#isLoading_bid").show();
      
    } else {
      $("#btn_bid_stop").hide();
      $('#btn_bid_go').show();
      $("#isLoading_bid").hide();
      
    }
  });
}

function getCollectStatus() {
  chrome.storage.local.get("collect_status", function(obj){
    if(obj.collect_status == 'go') {
     $("#btn_collect").hide();
      $("#btn_stop").show();
      $("#isLoading").show();
      
    } else {
      $("#btn_collect").show();
      $("#btn_stop").hide();
      $("#isLoading").hide();
      
    }
  });
}

function getStatusNums() {
  chrome.storage.local.get("jobsArr", function(items){
    if(items.jobsArr && items.jobsArr.length) {
      $("#collected_nums").text(items.jobsArr.length);
    } else {
      $("#collected_nums").text("0");
    }  
  });

  chrome.storage.local.get("sent_nums", function(obj){
    if(obj.sent_nums) {
      $("#sent_nums").text(obj.sent_nums);
    } else {
      $("#sent_nums").text("0");
    }  
  });
}

function getTexts() {
  chrome.storage.local.get("filter_text", function(obj){
    if(obj.filter_text) {
      $("#filter_jobs_text").val(obj.filter_text);
    } else {
      $("#sent_nums").val("");
    }  
  }); 
  chrome.storage.local.get("bid_Txt", function(obj){
    if(obj.bid_Txt) {
      $("#messageTxt").val(obj.bid_Txt);
    } else {
      $("#messageTxt").val("");
    }  
  });
}
// Main function
$(function() {

  $("#isLoading").hide();
  $("#btn_stop").hide();

  getBidStatus();
  getCollectStatus();
  getTexts();
  getStatusNums();
  setInterval(function(){ getStatusNums() }, 500);


  chrome.storage.local.get("jobsArr", function(items){
    if(items.jobsArr && items.jobsArr.length) {
      $("#collected_nums").text(items.jobsArr.length);
    } else {
      $("#collected_nums").text("0");
    }
    
  });

  $("#clear_collect").click(function() {
    chrome.storage.local.set({ "jobsArr": []});
    $("#collected_nums").text("0");
  });

  getCurrentTab(function(currentTab) {
    console.log("currentTab:   ", currentTab);
    // collect 
    $('#btn_collect').click(function() {
      if (currentTab.url.indexOf('https://angel.co/jobs') == -1) {
        chrome.tabs.create({url: "https://angel.co/jobs"});
        return;
      }
      var filterTxt = $("#filter_jobs_text").val();
      chrome.storage.local.set({ "collect_status": 'go'}, function() {
        getCollectStatus();
        chrome.storage.local.set({"filter_text": filterTxt}, function(obj){
          chrome.tabs.sendMessage(
            currentTab.id, {
              action: 'collect_jobs',
              status: 'go',
              filterTxt: filterTxt
            }
          );
        }); 

      });
    });

    $('#btn_stop').click(function() {
      chrome.storage.local.set({ "collect_status": 'stop'}, function() {
        getCollectStatus();
        chrome.tabs.sendMessage(
          currentTab.id, {
            action: 'collect_jobs',
            status: 'stop'
          }
        );
        chrome.storage.local.get("jobsArr", function(items){
          if(items.jobsArr && items.jobsArr.length) {
            $("#collected_nums").text(items.jobsArr.length);
          } else {
            $("#collected_nums").text("0");
          }
          console.log("collected items:  ", items);
        });
      });
    });

    // bids
    
    $('#btn_bid_go').click(function() {
      var msgTxt = $("#messageTxt").val();
      chrome.storage.local.set({ "bid_status": 'go'}, function() {
        getBidStatus();
         chrome.storage.local.set({"bid_Txt": msgTxt}, function(obj){
          chrome.tabs.sendMessage(
            currentTab.id, {
              action: 'bid_jobs',
              status: 'go',
              msgTxt: msgTxt
            }
          );
        });
      });
    });

    $('#btn_bid_stop').click(function() {
      chrome.storage.local.set({ "bid_status": 'stop'}, function() {
        getBidStatus();
        chrome.tabs.sendMessage(
            currentTab.id, {
              action: 'bid_jobs',
              status: '',
              msgTxt: ''
            }
          );
      });
    });

  });
});



chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action == 'close_action_1') {
    console.log('action is closed');
    $("#btn_collect").show();
    $("#btn_stop").hide();
    $("#isLoading").hide();
    $("#desc_go").show();
    $("#desc_stop").hide();
  }

});